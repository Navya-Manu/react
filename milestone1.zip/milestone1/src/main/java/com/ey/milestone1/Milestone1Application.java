package com.ey.milestone1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Milestone1Application {

	public static void main(String[] args) {
		SpringApplication.run(Milestone1Application.class, args);
	}

}
