package com.ey.springboot.Product;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
//import javax.validation.constraints.NotBlank;
//import javax.validation.constraints.NotNull;
 
@Entity
@Table(name = "product")
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    
    private Integer id;
    
    @Column(name="productId")
    private Integer productId;
    
    @Column(name="productName")
//    @NotBlank
    private String productName;
    
   // @NotNull
    @Column(name="quantity")
    private Integer quantity;
    
   // @NotNull
    @Column(name="price")
    private Integer price;
    
    public Product()
    {
    	
    }

	public Product(Integer productId, String productName, Integer quantity, Integer price) {
	super();
	this.productId = productId;
	this.productName = productName;
	this.quantity = quantity;
	this.price = price;
}

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public Integer getPrice() {
		return price;
	}

	public void setPrice(Integer price) {
		this.price = price;
	}
    
    
}