package com.ey.springboot.ProductRepository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ey.springboot.Product.Product;

public interface ProductRepository extends JpaRepository<Product, Long> {
}