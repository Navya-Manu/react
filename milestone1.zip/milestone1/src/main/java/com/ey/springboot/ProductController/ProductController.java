package com.ey.springboot.ProductController;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.*;

import com.ey.springboot.Product.Product;
import com.ey.springboot.ProductRepository.ProductRepository;
import com.ey.springboot.ProductService.ProductService;

//import javax.validation.Valid;
import java.util.List;
import java.util.Map;
 
@RestController
@RequestMapping("/api/v1")
public class ProductController {
    
    @Autowired
    private ProductRepository productRepository;
    
    
    @GetMapping("/products")
    public List<Product> getAllProducts(){
    	return productRepository.findAll();
    }
    
    
    
    @PostMapping("/products")
    public Product createProduct(@RequestBody Product product) {
    	return productRepository.save(product);
    }
    
    @DeleteMapping("/products/{id}")
    public ReponsiveEntity<Map<String,Boolean>> deleteProduct(@PathVariable Long id){
    	Product product=productRepository.findById(id)
    			.orElseThrow(() -> new ResourseNotFoundException("Product not exist with id:" +id));
    	
    	productRepository.delete(product)
    	Map<String,Boolean> response=new HashMap<>();
    	response.put("deleted", Boolean.TRUE);
    	return ResponseEntity.ok(response);
    }
    
//    @PostMapping("/products")
//    public ResponseEntity<Product> addProduct( @RequestBody Product product) {
//        Product addedProduct = productService.addProduct(product);
//        return new ResponseEntity<>(addedProduct, HttpStatus.CREATED);
//    }
    
    // Implement other endpoints similarly
}