package com.ey.springboot.ProductService;

import com.ey.springboot.Product.Product;

//import com.ey.springboot.Product;

import antlr.collections.List;

public interface ProductService {
    Product addProduct(Product product);
    void deleteProduct(Integer productId);
    Product updateProduct(Long productId, Product product);
    Product getProduct(Long productId);
    //List<Product> getAllProducts();
}