public interface ProductService {
    Product addProduct(Product product);
    void deleteProduct(Long productId);
    Product updateProduct(Long productId, Product product);
    Product getProduct(Long productId);
    List<Product> getAllProducts();
}